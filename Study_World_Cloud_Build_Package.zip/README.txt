STUDY WORLD ANDROID PROJECT

This is an Android Studio project that wraps the Study World mobile portal in a native Android WebView shell.

BUILD APK:
1. Install Android Studio (current stable version).
2. Open this folder as an existing project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

For a shareable release APK, use Build > Generate Signed Bundle / APK and create a signing key.
The included portal content is a starter template. Replace the sample links with your real quiz,
mock test, current affairs, study materials and recruitment update URLs before publishing.

Package: com.studyworld.portal
App name: Study World
Minimum Android: Android 6.0 (API 23)

CLOUD BUILD FROM ANDROID PHONE (GitHub Actions):
1. Sign in/create an account at https://github.com
2. Create a NEW PUBLIC or PRIVATE repository named StudyWorld (private is fine).
3. In the repository, use Add file > Upload files and upload the CONTENTS of this project folder,
   including the hidden .github folder. If the phone file picker hides hidden folders, create
   .github/workflows/android-build.yml in GitHub's web editor and paste the workflow file.
4. Commit the files to the main branch.
5. Open the repository's Actions tab and select "Build Study World APK".
6. If needed, choose Run workflow > Run workflow.
7. Wait for the workflow to finish successfully. Open the run and download the
   "Study-World-APK" artifact. Extract the downloaded artifact ZIP to get app-debug.apk.
This produces a debug APK signed with Android's debug key for testing, not a Play Store release.
Do not upload private signing keys or passwords to the repository.
